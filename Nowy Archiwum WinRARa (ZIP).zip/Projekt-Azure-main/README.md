# Sports Analyzer API

## Opis
Aplikacja oferująca analizę statystyk drużyn i zawodników w modelu subskrypcyjnym.

## Uruchomienie lokalne
```
pip install -r requirements.txt
uvicorn app.main:app --reload
```
